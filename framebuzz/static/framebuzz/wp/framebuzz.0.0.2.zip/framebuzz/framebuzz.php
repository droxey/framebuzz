<?php 
/* 
Plugin Name: FrameBuzz Embedder 
Plugin URI: http://www.framebuzz.com/ 
Description: Description will appear here. 
Version: 0.0.2 
Author: FrameBuzz 
Author URI: http://www.framebuzz.com/ 
License: GPLv2 or later 
*/ 

function framebuzz_activation() { 
} 
register_activation_hook(__FILE__, 'framebuzz_activation'); 

function framebuzz_deactivation() { 
} 
register_deactivation_hook(__FILE__, 'framebuzz_deactivation'); 


//add a button to the content editor, next to the media button
//this button will show a popup that contains inline content
add_action('media_buttons_context', 'add_my_custom_button');

//add some content to the bottom of the page 
//This will be shown in the inline modal
add_action('admin_footer', 'add_inline_popup_content');

//action to add a custom button to the content editor
function add_my_custom_button($context) {
    $default  = '[framebuzz src=http://frame.bz/v/_-uH4_kDfow width=640 height=440]';
    $href     = 'href="javascript:send_to_editor(\''.$default.'\');"';
    
    $context .= '<a title="Add FrameBuzz video" class="button add_media"'.$href.'><span class="wp-media-buttons-icon"></span> Add FrameBuzz video</a>'; 
    return $context;
}

function add_inline_popup_content() {
}


if ( ! function_exists( 'framebuzz_embed_shortcode' ) ) :

	function framebuzz_enqueue_script() {
		wp_enqueue_script( 'jquery' );
	}
	add_action( 'wp_enqueue_scripts', 'framebuzz_enqueue_script' );
	
	function framebuzz_embed_shortcode( $atts, $content = null ) {
		$defaults = array(
			'src' => 'http://frame.bz/v/_-uH4_kDfow',
			'width' => '640',
			'height' => '440',
			'scrolling' => 'no',
			'class' => 'framebuzz-class',
			'frameborder' => '0'
		);

		foreach ( $defaults as $default => $value ) { // add defaults
			if ( ! @array_key_exists( $default, $atts ) ) { // hide warning with "@" when no params at all
				$atts[$default] = $value;
			}
		}

        $html  = "\n".'<!-- framebuzz plugin v.1.0 wordpress.org/plugins/framebuzz/ -->'."\n";
		$html .= '<iframe ';
        foreach( $atts as $attr => $value ) {
    		if( $value != '' ) { // adding all attributes
				$html .= ' ' . $attr . '="' . $value . '"';
			} else { // adding empty attributes
				$html .= ' ' . $attr;
			}
		}
		$html .= '></iframe>';
		return $html;
	}
	add_shortcode( 'framebuzz', 'framebuzz_embed_shortcode' );
   
	
endif;
?>